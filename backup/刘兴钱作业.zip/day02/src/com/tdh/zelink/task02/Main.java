package com.tdh.zelink.task02;

/**
 * @author ZeLink
 * @Description
 * @date 2021/4/15  10:49
 */
public class Main {
    public static void main(String[] args) {
        Task21 task21 = new Task21();
        task21.getTime();
        task21.addUser();
//        System.out.println(task21.getRandomName());
    }
}
