package com.tdh.zelink.task03;

/**
 * @author ZeLink
 * @Description
 * @date 2021/4/15  16:13
 */
public class Main {
    public static void main(String[] args) {
        Task31 task31 = new Task31();
        task31.selectData();
    }
}
