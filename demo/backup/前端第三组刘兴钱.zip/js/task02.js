$(function () {
    function getForm() {
        let user = {

            userName: trim($('[name="userName"]').val()),
            userPasswd: trim($('[name="userPasswd"]').val()),
            userSex: trim($('[name="sex"]:checked').val()),
            hobby: [],
            depart: trim($('[name="depart"]:checked').val()),
            myProflie: trim($('[name="myProflie"]').val()),
        }
        let hobby = $('[name="hobby"]');
        console.log(hobby)
        console.log(hobby[0])
        for (let i = 0; i < hobby.length; i++) {
            if (hobby[i].checked == true) {
                user.hobby.push(hobby[i].value)
            }

            // user.hobby.push(hobby[key].val())
        }
        let userField = {
            userName: "用户姓名",
            userPasswd: '用户口令',
            userSex: '用户性别',
            hobby: '兴趣爱好',
            depart: '用户部门',
            myProflie: '自我介绍',
        }
        let userFieldShorthand = {
            userName: "yhxm",
            userPasswd: 'yhkl',
            userSex: 'yhxb',
            hobby: 'xqao',
            depart: 'yhbm',
            myProflie: 'zwjs',
        }
        console.log(user)
        let s = '请检查必须填写：';
        let userMessage = '';
        for (let key in user) {
            if (user[key] == '' || key == undefined) {
                if (userField[key]) {
                    s = s + userField[key] + '、';
                }
            } else {
                if (key === 'hobby') {
                    for (let i in user.hobby) {
                        console.log(i)
                        userMessage = userMessage + '&' + userFieldShorthand[key] + '=' + encodeStr(user.hobby[i]);

                    }

                }
                else {
                    userMessage = userMessage + '&' + userFieldShorthand[key] + '=' + encodeStr(user[key]);

                }
            }
        }
        console.log(s)

        array = s.split('、')
        s = ''
        for (let index = 0; index < array.length - 1; index++) {
            s = s + array[index]
            if (index < array.length - 2) {
                s = s + '、';
            }

        }
        console.log(s)
        console.log()
        return s == '' ? userMessage : s;


    }
    // 对参数编码
    function encodeStr(val) {
        return encodeURIComponent(encodeURIComponent(trim(val)));
    }
    $('#save').click(function () {
        let message = getForm();
        alert(message)
        return false;
    })
    $('#close').click(function () {
        window.close();
    })
    //去掉空格
    function trim(value) {
        if (value)
            value = value.replace(/^\s*|\s*$/g, "");
        if (!value)
            return "";
        else
            return value;
    }
})