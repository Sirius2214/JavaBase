$(function () {
    let messages = [{
        userId: 'test1',
        userName: '测试1',
        userDepart: '部门1'
    }, {
        userId: 'test2',
        userName: '测试2',
        userDepart: '部门2'
    },
        , {
        userId: 'test3',
        userName: '测试3',
        userDepart: '部门3'
    },
    ];
    for (let obj in messages) {
        // console.log(obj)
        let s = "<tr ><td>" + messages[obj].userId + "</td><td>" + messages[obj].userName + "</td><td>" + messages[obj].userDepart + "<td></td></td></tr>"
        $(message).append(s);
    }


    $(search).click(function () {
        // console.log( $("td").text())
        // let str=$("td").text();
        // str=str.split(" ");
        // console.log(str)
        let userID = $(userid).val();
        let userDepart = $(user_department).val();
        alert(encodeStr(userID, userDepart))

    })
    $(add).click(function () {
        openwindow('/task/task02.html', '', 620, 250)


    })
    //去掉空格
    function trim(value) {
        if (value)
            value = value.replace(/^\s*|\s*$/g, "");
        if (!value)
            return "";
        else
            return value;
    }
    // 对参数编码
    function encodeStr(val, val2) {
        return "&yhxx=" + encodeURIComponent(encodeURIComponent(trim(val))) +
            "&yhbm=" + encodeURIComponent(encodeURIComponent(trim(val2)));
    }
    function openwindow(url, name, iWidth, iHeight) {
        var url;
        var name;
        var iWidth;
        var iHeight;
        var iTop = (window.screen.height - 30 - iHeight) / 2;
        var iLeft = (window.screen.width - 10 - iWidth) / 2;
        window.open(url, name, 'height=' + iHeight + ',innerHeight=' + iHeight + ',width=' + iWidth + ',innerWidth=' + iWidth + ',top=' + iTop + ',left=' + iLeft + ',toolbar=no,menubar=no,scrollbars=auto,resizeable=no,location=no,status=no');
    }


}
)
